total=0;
for i=1:104
  
    
    nums=find(sb_existance_data{i}==1);
    total=total+size(nums,2);
    
end
